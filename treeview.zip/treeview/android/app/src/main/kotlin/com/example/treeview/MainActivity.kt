package com.example.treeview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

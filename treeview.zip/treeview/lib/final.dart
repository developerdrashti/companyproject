import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_treeview/flutter_treeview.dart';

class TreeViewExample extends StatefulWidget {
  const TreeViewExample({Key? key}) : super(key: key);

  @override
  State<TreeViewExample> createState() => _TreeViewExampleState();
}

class _TreeViewExampleState extends State<TreeViewExample> {
  // List<Node>? nodes = [];
  List<Map<String, dynamic>> data = [];

  // Modal? modal;
  @override
  void initState() {
    loadAPIData().whenComplete(() {
      setState(() {});
    });
    super.initState();
  }

  Node _buildNode(Map<String, dynamic> item) {
    final children = data.where((e) => e['parentID'] == item['id']).toList();
    var nodename = item['name'] ?? "null";
    var id = item['id'].toString();
    var nodelaval = item['level'].toString();

    print(">>>1)>>${nodename}");
    print(">>>2)>>${id}");
    List<dynamic> listdata = [
      "Id:${id}",
      "N:${nodename}",
      "L:${nodelaval}",
    ];
    print(">>>3)>>${listdata}");

    return Node(
      icon: Icons.person,
      expanded: true,
      selectedIconColor: Colors.brown,
      key: item['id'].toString(),
      label: listdata.toString(),
      children: children.isNotEmpty
          ? [
        for (final child in children) _buildNode(child),
      ]
          : [],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: double.maxFinite,
        width: double.maxFinite,
        child: Padding(
          padding: const EdgeInsets.only(top: 25.0),
          child: TreeView(
            controller: TreeViewController(children: [
              for (final item in data) _buildNode(item),
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> loadAPIData() async {
    String url = 'https://gmpsapi.netpairsoftware.com/api/Selter/GetFamilyTree';
    var result = await Dio().get(url);
    if (result.statusCode == 200) {
      List<dynamic> data1 = result.data['lists'];
      print('data1---> ${data1.length}');
      List<Map<String, dynamic>> data2 = [];
      data1.forEach((element) {
        data2.add(element);
      });
      data = data2;

      print('data---> ${data.length}');
    }
  }
}